#include<reg51.h>

void delay_5ms()
{
  unsigned char i,j;

  for(i=0;i<=25;i++)
    for(j=0;j<=200;j++);
}

unsigned char key_scan()
{
  unsigned char key_temp0,key_temp1;
  unsigned char key_num=0;

  P1=0x0f;
  key_temp0=P1;
  if(key_temp0!=0x0f)
  {
    delay_5ms();
	key_temp0=P1;
	if(key_temp0!=0x0f)
	{
	  P1=0xf0;
	  key_temp1=P1;
	  if(key_temp0==0x0e)
	  {
	    switch(key_temp1)
		{
		  case 0xe0: key_num=4;break;
		  case 0xd0: key_num=3;break;
		  case 0xb0: key_num=2;break;
		  case 0x70: key_num=1;break;
		  default: key_num=0;break;
		}
	  }
	  else if(key_temp0==0x0d)
	  {
	   	switch(key_temp1)
		{
		  case 0xe0: key_num=8;break;
		  case 0xd0: key_num=7;break;
		  case 0xb0: key_num=6;break;
		  case 0x70: key_num=5;break;
		  default: key_num=0;break;
		}
   
	  }
	  else if(key_temp0==0x0b)
	  {
	  	switch(key_temp1)
		{
		  case 0xe0: key_num=12;break;
		  case 0xd0: key_num=11;break;
		  case 0xb0: key_num=10;break;
		  case 0x70: key_num=9;break;
		  default: key_num=0;break;
		}

	  }
	  else if(key_temp0==0x07)
	  {
	  	switch(key_temp1)
		{
		  case 0xe0: key_num=16;break;
		  case 0xd0: key_num=15;break;
		  case 0xb0: key_num=14;break;
		  case 0x70: key_num=13;break;
		  default: key_num=0;break;
		}
	  }
	}
  }

  return key_num;
}

void main()
{
  unsigned char key_num;

  do{
    key_num=key_scan();
	P2=key_num/10;
	P3=key_num%10;
  }while(1);
}
#include<reg52.h>
sbit led=P1^1;
//�жϳ�ʼ������
void tx_init()
{
  TMOD=0x60;
  TH1=0x9c;
  TL1=0x9c;
  ET1=1;
  EA=1;
  TR1=1;
  led=1;
}

void main()
{
  tx_init();
  while(1);
}

void tx0_func() interrupt 3
{
  led=~led;
  led=~led;
}
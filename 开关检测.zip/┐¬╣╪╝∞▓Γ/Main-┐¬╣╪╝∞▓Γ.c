#include "reg51.h"
#define uchar unsigned char
#define uint unsigned int
sbit in=P3^0;
sbit out=P1^0;

void main(void)
{

while(1)
	{
	 in=1;if(in==0)out=0;else out=1;
	}

}

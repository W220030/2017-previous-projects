#include<reg52.h>
unsigned char code table[]={0x3f,0x06,0x5b,0x4f,
                            0x66,0x6d,0x7d,0x07,
							0x7f,0x6f,0x77,0x7c,
							0x39,0x5e,0x79,0x71};

unsigned char keyscan()
{
  unsigned char keyvalue,temp;

  keyvalue=0;
  P2=0xff;
  temp=P2;
  if(~(P2&temp))
  {
    switch(temp)
	{
	  case 0xfe:  
	    keyvalue=1;
	    break;
	  case 0xfd:
	    keyvalue=2;
	    break;
	  case 0xfb:
	    keyvalue=3;
	    break;
	  case 0xf7:
	    keyvalue=4;
	    break;
	  default:
	    keyvalue=0;
	    break;
	}
  }

  return keyvalue;
}

void main()
{
  unsigned char ledshow;

  while(1)
  {
    ledshow=keyscan();
	P1=table[ledshow];
  }
}
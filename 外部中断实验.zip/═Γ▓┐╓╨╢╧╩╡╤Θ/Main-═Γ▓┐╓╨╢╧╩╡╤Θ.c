#include<reg52.h>
unsigned char code table[]={0x01,0x02,0x04,0x08,
                            0x10,0x20,0x40,0x80};

void delay(unsigned char delay_time)
{
  unsigned char i,j;

  for(i=0;i<=delay_time;i++)
  {
    for(j=0;j<=200;j++);
  }
}

void init_tx()
{
  EA=1;
  EX0=1;
  IP=0x00;
}

void main()
{
  unsigned char i;

  init_tx();
  while(1)
  {
    for(i=0;i<8;i++)
	{
	  P1=table[i];
	  delay(200);
	}
  }
}

void tx0() interrupt 0
{
  unsigned char i;

  P1=0x00;
  delay(200);
  for(i=0;i<=15;i++)//ע�⣬��˸8��Ӧ�ý���16�ε�ƽ��ת
  {
    P1=~P1;
	delay(200);
  }
}
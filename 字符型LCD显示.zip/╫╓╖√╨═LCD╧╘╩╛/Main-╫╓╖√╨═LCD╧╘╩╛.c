#include<reg51.h>
#include<lcd1602.h>

unsigned char code date[]="  H.I.T. CHINA  ";
unsigned char code time[]=" TIME  21:37:40 ";

void clock_init()
{
  uchar i,j;

  for(i=0;i<16;i++)
  {
    write_data(date[i]);
  }
  write_com(0x80+0x40);
  for(j=0;j<16;j++)
  {
    write_data(time[j]);
  }
}

void main()
{
  init1602();
  clock_init();
}
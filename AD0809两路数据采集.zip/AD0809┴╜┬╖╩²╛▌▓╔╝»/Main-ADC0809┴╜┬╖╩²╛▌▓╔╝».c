/******************************************************************************/

#include <reg51.h>
#define uchar unsigned char

sbit dula=P2^0;
sbit wela=P2^1;

sbit CLK=P1^3;
sbit ST=P1^2;
sbit OE=P1^0;
sbit EOC=P1^1;

sbit wei1=P2^1;
sbit wei2=P2^2;
sbit wei3=P2^3;

sbit wei4=P2^5;
sbit wei5=P2^6;
sbit wei6=P2^7;

uchar code dulatab[]={0x3f,0x06,0x5b,0x4f,0x66,
					  0x6d,0x7d,0x07,0x7f,0x6f,0x40}; //���ֱ���0-9
uchar code welatab[]={0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f};//λ������

uchar count;

void delay(uchar time)	 //��ʱ
{
	uchar i,j;
	for(i=0;i<time;i++)
	{
		for(j=0;j<110;j++)
		;
	}
}

/*********ϵͳ��ʼ��***********/
void init()
{
 P2=0xff;
 EA = 1;                     //�����ж�
 TMOD = 0x02;                //�趨��ʱ��T0������ʽ  
 TH0=216;                    //����T0�жϲ���CLK�ź�
 TL0=216;					 //��ʱ40usƵ��25K
 TR0=1;                      //������ʱ��T0
 ET0=1;
 ST=0;
 OE=0;  
 P1=0x30;
}

void write1(uchar num)
{

	uchar i,j,k;
	k=num/100;
	j=num%100/10;
	i=num%10;

	P2=0xff;
	P0=dulatab[k];
	wei4=0;

	delay(4);
	
	P2=0xff;
	P0=dulatab[j];
	wei5=0;

	delay(4);
	
	P2=0xff;
	P0=dulatab[i];
	wei6=0;

	delay(4);
}

void write0(uchar num)
{
	uchar i,j,k;
	k=num/100;
	j=num%100/10;
	i=num%10;

	P2=0xff;
	P0=dulatab[k];
	wei1=0;

	delay(4);
	
	P2=0xff;
	P0=dulatab[j];
	wei2=0;

	delay(4);
	
	P2=0xff;
	P0=dulatab[i];
	wei3=0;

	delay(4);

}
uchar adin0()
{
	uchar value;
	OE=0;
	EOC=1;
	ST=0;
	P1&=0x8f;
	P1|=0x30;
	delay(10);
	ST=1;
	delay(10);
	ST=0;
	while(!EOC);
//	EOC=0;
	delay(10);
	OE=1;
	delay(1);
	value=P3;
	OE=0; 
	return value;
}
uchar adin1()
{
	uchar value;
	OE=0;
	EOC=1;
	ST=0;
	P1&=0x8f;
	P1|=0x00;
	delay(10);
	ST=1;
	delay(10);
	ST=0;
	while(!EOC);
//	EOC=0;
	delay(10);
	OE=1;
	delay(1);
	value=P3;
	OE=0; 
	return value;
}
void main()
{
	uchar in0,in1;
	init();
	while(1)
	{
		in0=adin0();
		write0(in0);
		in1=adin1();
		write1(in1);
	}		
}

void timer0(void) interrupt 1
{
 CLK=~CLK;
}
#include<reg52.h>

unsigned char second,timer;

void t1_init()
{
  TMOD=0x10;
  IE=0x88;
  TH1=0x3c;
  TL1=0xb0;
  TR1=1;
}

void main()
{
  t1_init();
  second=59;
  timer=0;
  while(1);
}

void t1_func() interrupt 3
{
  TH1=0x3c;
  TL1=0xb0;
  if(timer<20)
  {
    timer=timer+1;
  }
  else if(timer==20)
  {
    timer=0;
    if(second==0)
    {
      second=59;
    }
    else
    {
      second=second-1;
    }
  }
  P2=second/10;
  P3=second%10;
} 